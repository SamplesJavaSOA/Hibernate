package com.samuel.tutorial.hibernate.client;

public class ProcMap {

}
