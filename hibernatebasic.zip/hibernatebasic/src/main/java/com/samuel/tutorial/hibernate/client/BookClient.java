package com.samuel.tutorial.hibernate.client;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import com.samuel.tutorial.hibernate.dao.GenericDAO;
import com.samuel.tutorial.hibernate.dao.HibernateUtil;

import com.samuel.tutorial.hibernate.entity.Author;
import com.samuel.tutorial.hibernate.entity.Book;

public class BookClient {
	public static void main(String[] args) throws Exception {
		//seedDB();
		StoredProcExample();
	}

	private static void StoredProcExample() {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Query sq =  session.createSQLQuery("call testuser.HibernateResultsetExample");
		List ls = sq.list();
		System.out.println(ls.size());
		for(Object o: ls){
			Object[] book = (Object[]) o;
			System.out.println(book[0]+"/"+book[1]+"/"+book[2]+"/");
		}
	}

	private static void seedDB() throws Exception {
		List<Author> authors = new ArrayList<Author>();
		Author a = new Author();
		a.setName("Hans Christian Anderson");
		authors.add(a);
		a = new Author();
		a.setName("J K Rowling");
		authors.add(a);
		
		Book b = new Book();
		b.setName("Fairy Stories");
		b.setAuthors(authors);
		b.setPrice(300);
		
		
		GenericDAO gd = new GenericDAO();
		gd.insertObject(b);

		List<Author> authors2 = new ArrayList<Author>();
		Author a2 = new Author();
		a2 = new Author();
		a2.setName("Matthew B.J. Delaney");
		authors2.add(a2);
		
		Book b2 = new Book();
		b2.setName("Black Rain");
		b2.setAuthors(authors2);
		b2.setPrice(500);

		gd.insertObject(b2);

	}
}
