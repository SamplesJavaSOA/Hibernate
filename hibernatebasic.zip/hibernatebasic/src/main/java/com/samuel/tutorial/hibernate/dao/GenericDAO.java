package com.samuel.tutorial.hibernate.dao;

import java.util.List;


import org.hibernate.Session;



public class GenericDAO {


	public void insertObject(Object o) throws Exception {
		Session session = HibernateUtil.getSessionFactory().openSession();
		
		// Start a transaction
		session.beginTransaction();
		//Save Object in database
		session.save(o);
		session.flush();
		session.getTransaction().commit();
		//Close the session
		session.close();
		}


}