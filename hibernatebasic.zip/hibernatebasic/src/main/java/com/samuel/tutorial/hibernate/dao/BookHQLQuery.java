package com.samuel.tutorial.hibernate.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.transform.Transformers;


import com.samuel.tutorial.hibernate.entity.Book;
import com.samuel.tutorial.hibernate.entity.Author;



public class BookHQLQuery {

	public static void main(String[] args) {
		BookHQLQuery bookHQLQuery = new BookHQLQuery();
		List<Book> books = bookHQLQuery.getBooks();
		
		//List books = bookHQLQuery.getBooks("%Hans%","%Dela%");
	}
	
	public List<Book> getBooks(String auth1,String auth2){
		Session session = HibernateUtil.getSessionFactory().openSession();
		//String hql ="from Book";
		String hql ="select book.id as id, book.name as name ,book.price as proce, author.name as authorName from Book book join book.authors author where author.name like :authorName";
		
		Query query = session.createQuery(hql);
		query.setParameter("authorName", auth1);
		List books =query.list();
		
		
		System.out.println(books.size());
		for(Object o: books){
			Object[] book = (Object[]) o;
			System.out.print(book[0]+"/");
			System.out.print(book[1]+"/");
			System.out.print(book[2]+"/");
			System.out.println(" Price: "+ book[3]);
		}
		return books;
	}
	
	public List<Book> getBooks(){
		Session session = HibernateUtil.getSessionFactory().openSession();
		//String hql ="from Book";
		String hql ="from Book book";
		
		Query query = session.createQuery(hql);

		List<Book> books =query.list();
		System.out.println(books.size());
		for(Book book: books){
			
			System.out.print(book.getName() + "By : ");
			
			System.out.println(" Price: "+ book.getPrice());
		}
		return books;
	}

}
