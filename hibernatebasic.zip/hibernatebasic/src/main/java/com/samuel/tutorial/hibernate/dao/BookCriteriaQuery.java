package com.samuel.tutorial.hibernate.dao;



import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.LogicalExpression;
import org.hibernate.criterion.Restrictions;

import com.samuel.tutorial.hibernate.entity.Author;
import com.samuel.tutorial.hibernate.entity.Book;

public class BookCriteriaQuery {

	public static void main(String[] args) {
		BookCriteriaQuery bookCriteriaQuery = new BookCriteriaQuery();
		//List<Book> books = bookCriteriaQuery.getBooks("Hans Christian Anderson", "%dela%");
		List<Book> books = bookCriteriaQuery.getBooks("%Row%");
		//List<Book> books = bookCriteriaQuery.getBooks("Hans Christian %");
		//List<Book> books = bookCriteriaQuery.getBooks(200, 900);
		System.out.println(books.size());
		for(Book book: books){
			System.out.print(book.getName() + "By : ");
			for(Author author: book.getAuthors()){
				System.out.print(author.getName()+",");
			}
			System.out.println(" Price: "+ book.getPrice());
		}
		

	}
	
	public List<Book> getBooks(String authorName){
		Session session = HibernateUtil.getSessionFactory().openSession();
		Criteria cr = session.createCriteria(Book.class);
		cr.createAlias("authors", "auth"); 
		cr.add(Restrictions.ilike("auth.name", authorName));
		
		
		List<Book> books = cr.list();
		return books;
	}
	
	/* And Example */
	public List<Book> getBooks(int minPrice, int maxPrice){
		Session session = HibernateUtil.getSessionFactory().openSession();
		Criteria cr = session.createCriteria(Book.class);
		cr.add(Restrictions.gt("price", minPrice));
		cr.add(Restrictions.lt("price", maxPrice));
		
		List<Book> books = cr.list();
		return books;
	}
	
	public List<Book> getBooks(String author, String author2){
		Session session = HibernateUtil.getSessionFactory().openSession();
		Criteria cr = session.createCriteria(Book.class);
		cr.createAlias("authors", "auth");
		
		Criterion a1 = Restrictions.ilike("auth.name", author);
		Criterion a2 = Restrictions.ilike("auth.name", author2);
		LogicalExpression orExp = Restrictions.or(a1, a2);
				
		cr.add(orExp);	
		List<Book> books = cr.list();
		return books;
	}


}
