package com.t2t.servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.t2t.lnd.jspservlet.dao.UserDAO;
import com.t2t.lnd.jspservlet.dao.UserService;

public class LoginProcessor extends HttpServlet {

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// 1. Get the request parameters
		String userName = request.getParameter("userName");
		String password = request.getParameter("password");
		String error ="";
		
		String comp = getServletContext().getInitParameter("companyName");

		UserService ul = new UserDAO();
		RequestDispatcher rd = getServletContext().getRequestDispatcher(
				"/LoginPage.jsp");

		try {
			if (ul.validateUser(userName, password)) {
				rd = getServletContext().getRequestDispatcher("/menu.jsp");
				HttpSession session = request.getSession();
				session.setAttribute("userName", userName);
			}else{
				error="Invalid username or password";
				request.setAttribute("error", error);
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		request.setAttribute("company", comp);
		rd.forward(request, response);

	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);

	}

}
