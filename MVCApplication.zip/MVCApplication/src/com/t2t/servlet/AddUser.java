package com.t2t.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.t2t.lnd.jspservlet.dao.UserDAO;
import com.t2t.lnd.jspservlet.data.User;

public class AddUser extends HttpServlet{
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	doPost(request, response);
	}
	

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String edit = ""+request.getParameter("edit");
		String update = ""+request.getParameter("update");
		if(edit.equals("y")){
			editUser(request, response);
		}else if(update.equals("y")){
			updateUser(request, response);
		}else{
		
			addUser(request, response);
		}
		
		
		
	}

	private void addUser(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		User user = createUser(request);
		
		UserDAO userDAO = new UserDAO();
		userDAO.addUser(user);
		RequestDispatcher rd = getServletContext().getRequestDispatcher("/menu.jsp");
		rd.forward(request, response);
	}

	private void updateUser(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		User user = createUser(request);
		
		UserDAO userDAO = new UserDAO();
		userDAO.updateUser(user);
		RequestDispatcher rd = getServletContext().getRequestDispatcher("/menu.jsp");
		rd.forward(request, response);
	}

	private User createUser(HttpServletRequest request) {
		int id = Integer.parseInt(request.getParameter("id"));
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		
		User user = new User();
		user.setId(id);
		user.setEmail(email);
		user.setName(name);
		user.setPassword(password);
		return user;
	}
	
	private void editUser(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		UserDAO userDAO = new UserDAO();
		User user =userDAO.getUser(id);
		
		request.setAttribute("user", user);
		RequestDispatcher rd = getServletContext().getRequestDispatcher("/EditUser.jsp");
		rd.forward(request, response);
	}

}
