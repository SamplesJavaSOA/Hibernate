package com.t2t.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.t2t.lnd.jspservlet.dao.UserDAO;
import com.t2t.lnd.jspservlet.data.User;

public class DisplayUser extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String edit = ""+request.getParameter("edit");
		
		UserDAO userDAO = new UserDAO();
		List<User> users = userDAO.getUsers();
		request.setAttribute("users", users);
		RequestDispatcher rd;
		if(edit.equals("y")){
			rd= getServletContext().getRequestDispatcher("/UserEditList.jsp");
		}else{
			rd= getServletContext().getRequestDispatcher("/UserList.jsp");
		}
		 
		rd.forward(request, response);
		
	}

}
