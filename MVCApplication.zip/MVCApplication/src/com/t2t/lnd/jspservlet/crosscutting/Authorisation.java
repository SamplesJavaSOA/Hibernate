package com.t2t.lnd.jspservlet.crosscutting;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Authorisation implements Filter{
	
	public void init(FilterConfig arg0) throws ServletException {}
	
	static int x = 0;
	
	public void doFilter(ServletRequest req, ServletResponse resp,
			FilterChain chain) throws IOException, ServletException {
		HttpServletRequest request = (HttpServletRequest) req;
		HttpSession session = request.getSession();
		HttpServletResponse response = (HttpServletResponse) resp;
		 
		if(request.getRequestURI().contains("/login")){ // if it is calling login servlet ok
			chain.doFilter(req, resp);
		}else if(session.getAttribute("userName") != null){ // Checks if user is logged in
			chain.doFilter(req, resp);
		}else{
			String error="You are not logged in";
			request.setAttribute("error", error);
			RequestDispatcher rd = request.getRequestDispatcher("/LoginPage.jsp");
			rd.forward(request, response);
		}
	}

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}
		
		
		

}
