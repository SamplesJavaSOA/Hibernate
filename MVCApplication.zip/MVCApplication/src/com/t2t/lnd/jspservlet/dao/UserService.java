package com.t2t.lnd.jspservlet.dao;

import java.sql.SQLException;
import java.util.List;

import com.t2t.lnd.jspservlet.data.User;

public interface UserService {
	
	public boolean validateUser(String userName, String password) throws SQLException, ClassNotFoundException;
	public int addUser(User user);
	public boolean changePassword(String userName, String password);
	public List<User> getUsers();
	
	

}
