package com.t2t.lnd.jspservlet.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Statement;
import com.t2t.lnd.jspservlet.data.User;

public class UserDAO implements UserService {

	private static final String USER_NAME = "jdbcTrain";
	private static final String PASSWORD = "jdbcTrain";
	private static final String JDBC_URI = "jdbc:mysql://127.0.0.1:3306/jspservlet";

	public static void main(String[] args) {

	}

	@Override
	public boolean validateUser(String userName, String password)
			throws SQLException, ClassNotFoundException {
		// 1. Load the Driver
		Class.forName("com.mysql.jdbc.Driver");

		// 2. Create a connection
		Connection con = DriverManager.getConnection(JDBC_URI, USER_NAME,
				PASSWORD);

		// 3. Create a Statement
		PreparedStatement st = con
				.prepareStatement("select name from User where name = ? and password=?");
		st.setString(1, userName);
		st.setString(2, password);

		// 4. Execute the statement(s)
		ResultSet rs = st.executeQuery();

		boolean result = false;

		if (rs.next()) {
			result = true;
		}
		// 5. Close the connection
		con.close();

		return result;

	}

	@Override
	public int addUser(User user) {

		String sql = "INSERT INTO jspservlet.user(id,name,email,password) VALUES (?,?,?,?)";
		try {
			Class.forName("com.mysql.jdbc.Driver");

			Connection con = DriverManager.getConnection(JDBC_URI, USER_NAME,PASSWORD);
			PreparedStatement st =  con.prepareStatement(sql);
			st.setInt(1, user.getId());
			st.setString(2, user.getName());
			st.setString(3, user.getEmail());
			st.setString(4, user.getPassword());
			st.executeUpdate();
			System.out.println("-------------");
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return 0;
	}

	@Override
	public boolean changePassword(String userName, String password) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<User> getUsers() {
		List<User> users = new ArrayList<User>();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(JDBC_URI, USER_NAME,
					PASSWORD);

			PreparedStatement st = con
					.prepareStatement("select id, name, email, password from User");
			ResultSet rs = st.executeQuery();

			while (rs.next()) {
				User user = new User();
				user.setId(rs.getInt("id"));
				user.setName(rs.getString("name"));
				user.setEmail(rs.getString("email"));
				users.add(user);
			}
			// 5. Close the connection
			con.close();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return users;

	}

	public User getUser(int id) {
		User user = new User();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(JDBC_URI, USER_NAME,
					PASSWORD);

			PreparedStatement st = con
					.prepareStatement("select id, name, email, password from User where id=?");
			st.setInt(1, id);
			ResultSet rs = st.executeQuery();

			rs.next();
				user.setId(rs.getInt("id"));
				user.setName(rs.getString("name"));
				user.setEmail(rs.getString("email"));
				user.setPassword(rs.getString("password"));
				
			
			// 5. Close the connection
			con.close();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return user;

	}

	public int updateUser(User user) {
		String sql = "update jspservlet.user set name=?, email=?, password=? where id=?";
		System.out.println(sql);
		try {
			Class.forName("com.mysql.jdbc.Driver");

			Connection con = DriverManager.getConnection(JDBC_URI, USER_NAME,PASSWORD);
			PreparedStatement st =  con.prepareStatement(sql);
			st.setInt(4, user.getId());
			st.setString(1, user.getName());
			st.setString(2, user.getEmail());
			st.setString(3, user.getPassword());
			st.executeUpdate();
			System.out.println("-------------");
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return 0;
		
	}


}
